# مولّد QR

موقع مفتوح المصدر لتوليد رموز QR، يعمل بالكامل داخل المتصفح. لا يوجد خادم، ولا مكتبات من الإنترنت، ولا خطوط أو طلبات شبكة خارجية، ولا يُرسل النص إلى أي جهة.

## المزايا

- نص أو رابط بأي لغة (يدعم العربية والإيموجي عبر UTF-8)
- مستويات تصحيح الأخطاء L / M / Q / H، واختيار القناع يدويًا أو تلقائيًا
- كل إصدارات QR من 1 إلى 40، ويُختار الأصغر المناسب تلقائيًا
- التحكم في الحجم والهامش وألوان الرمز والخلفية، مع تنبيه عند ضعف التباين
- تحميل PNG وSVG ونسخ الصورة
- سياسة أمان (CSP) في `index.html` تمنع أي اتصال خارجي

## التشغيل محليًا

افتح `index.html` في المتصفح مباشرة، أو شغّل خادمًا محليًا:

```bash
python3 -m http.server 8000
```

ثم افتح `http://localhost:8000`.

## النشر على GitHub Pages

```bash
git init
git add .
git commit -m "Initial commit: QR code generator"
git branch -M main
git remote add origin https://github.com/<USER>/<REPO>.git
git push -u origin main
```

ثم من إعدادات المستودع: **Settings → Pages → Build and deployment**، واختر **Deploy from a branch**، والفرع `main` والمجلد `/ (root)`.

## هيكل المشروع

```
index.html          الصفحة
css/style.css       التصميم
js/app.js           واجهة الموقع
js/qrcodegen.js     خوارزمية QR (Project Nayuki، MIT) مترجمة من TypeScript
LICENSE             رخصة المشروع مع إشعار رخصة الخوارزمية
```

## عن خوارزمية QR

الملف `js/qrcodegen.js` هو مكتبة **QR Code generator** من Project Nayuki بعد ترجمتها من TypeScript إلى JavaScript دون تعديل على المنطق:

```bash
tsc --strict --lib DOM,DOM.Iterable,ES6 --target ES2017 qrcodegen.ts
```

المكتبة مرخّصة بـ MIT، وإشعار الحقوق محفوظ أعلى الملف كما تشترط الرخصة. المصدر: https://github.com/nayuki/QR-Code-generator

## الرخصة

MIT. راجع ملف `LICENSE` (استبدل `[YOUR NAME]` باسمك).

---

## English

A client-side, open-source QR code generator. Everything runs in the browser: no server, no CDN, no third-party requests (enforced by a Content-Security-Policy). The encoder is Project Nayuki's MIT-licensed QR Code generator, bundled locally as `js/qrcodegen.js`. Supports versions 1–40, all four error-correction levels, mask selection, custom colors, and PNG/SVG export. Open `index.html` or serve the folder with any static server; deploy to GitHub Pages from the `main` branch root.

/*
 * QR generator UI.
 * Uses the locally bundled qrcodegen library (js/qrcodegen.js, Project Nayuki, MIT).
 * No network access is needed or used.
 */
"use strict";

(function () {
  var QrCode = qrcodegen.QrCode;
  var QrSegment = qrcodegen.QrSegment;
  var ECC = {
    L: QrCode.Ecc.LOW,
    M: QrCode.Ecc.MEDIUM,
    Q: QrCode.Ecc.QUARTILE,
    H: QrCode.Ecc.HIGH
  };

  function $(id) { return document.getElementById(id); }
  var el = {
    text: $("text"), count: $("count"), ecc: $("ecc"), mask: $("mask"),
    boost: $("boost"), size: $("size"), sizeOut: $("sizeOut"),
    margin: $("margin"), fg: $("fg"), bg: $("bg"), warn: $("warn"),
    canvas: $("canvas"), error: $("error"), empty: $("empty"),
    info: $("info"), dlPng: $("dlPng"), dlSvg: $("dlSvg"), copy: $("copy"),
    toast: $("toast")
  };

  var current = null; // { qr, border, scale, fg, bg }
  var toastTimer = 0;

  function utf8Length(s) { return new TextEncoder().encode(s).length; }

  function clampInt(v, lo, hi, fallback) {
    var n = parseInt(v, 10);
    if (isNaN(n)) n = fallback;
    return Math.min(hi, Math.max(lo, n));
  }

  function luminance(hex) {
    var c = [1, 3, 5].map(function (i) {
      var v = parseInt(hex.substr(i, 2), 16) / 255;
      return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
    });
    return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
  }

  function contrastRatio(a, b) {
    var la = luminance(a), lb = luminance(b);
    return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05);
  }

  function showError(msg) {
    el.error.textContent = msg;
    el.error.hidden = false;
  }

  function setActionsEnabled(on) {
    el.dlPng.disabled = !on;
    el.dlSvg.disabled = !on;
    el.copy.disabled = !on;
  }

  function showToast(msg) {
    el.toast.textContent = msg;
    el.toast.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.toast.hidden = true; }, 2500);
  }

  function drawToCanvas(canvas, qr, scale, border, fg, bg) {
    var total = qr.size + border * 2;
    var px = total * scale;
    canvas.width = px;
    canvas.height = px;
    var ctx = canvas.getContext("2d");
    ctx.imageSmoothingEnabled = false;
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, px, px);
    ctx.fillStyle = fg;
    for (var y = 0; y < qr.size; y++) {
      for (var x = 0; x < qr.size; x++) {
        if (qr.getModule(x, y)) {
          ctx.fillRect((x + border) * scale, (y + border) * scale, scale, scale);
        }
      }
    }
  }

  function toSvg(qr, scale, border, fg, bg) {
    var total = qr.size + border * 2;
    var px = total * scale;
    var parts = [];
    for (var y = 0; y < qr.size; y++) {
      for (var x = 0; x < qr.size; x++) {
        if (qr.getModule(x, y)) {
          parts.push("M" + (x + border) + "," + (y + border) + "h1v1h-1z");
        }
      }
    }
    return '<?xml version="1.0" encoding="UTF-8"?>\n' +
      '<svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="' + px +
      '" height="' + px + '" viewBox="0 0 ' + total + " " + total +
      '" stroke="none" shape-rendering="crispEdges">\n' +
      '\t<rect width="100%" height="100%" fill="' + bg + '"/>\n' +
      '\t<path d="' + parts.join(" ") + '" fill="' + fg + '"/>\n</svg>\n';
  }

  function render() {
    var text = el.text.value;
    var size = clampInt(el.size.value, 128, 1024, 320);
    var border = clampInt(el.margin.value, 0, 20, 4);
    var fg = el.fg.value, bg = el.bg.value;

    el.sizeOut.textContent = String(size);
    el.count.textContent = text
      ? text.length + " حرف · " + utf8Length(text) + " بايت"
      : "";

    // Contrast hint
    var warn = "";
    var ratio = contrastRatio(fg, bg);
    if (luminance(fg) > luminance(bg)) {
      warn = "لون الرمز أفتح من الخلفية (رمز معكوس)، وقد لا تقرأه بعض الماسحات.";
    } else if (ratio < 3) {
      warn = "التباين بين اللونين منخفض، وقد يصعب مسح الرمز.";
    }
    el.warn.textContent = warn;
    el.warn.hidden = warn === "";

    el.error.hidden = true;
    current = null;

    if (text === "") {
      el.canvas.hidden = true;
      el.empty.hidden = false;
      el.info.textContent = "";
      setActionsEnabled(false);
      return;
    }
    el.empty.hidden = true;

    var qr;
    try {
      qr = QrCode.encodeSegments(
        QrSegment.makeSegments(text),
        ECC[el.ecc.value],
        QrCode.MIN_VERSION,
        QrCode.MAX_VERSION,
        clampInt(el.mask.value, -1, 7, -1),
        el.boost.checked
      );
    } catch (e) {
      el.canvas.hidden = true;
      el.info.textContent = "";
      setActionsEnabled(false);
      showError("النص أطول من أقصى سعة لرمز QR بهذا المستوى من التصحيح. " +
        "قلّل النص أو اخفض مستوى تصحيح الأخطاء.");
      return;
    }

    var total = qr.size + border * 2;
    var scale = Math.max(1, Math.floor(size / total));
    drawToCanvas(el.canvas, qr, scale, border, fg, bg);
    el.canvas.hidden = false;
    current = { qr: qr, border: border, scale: scale, fg: fg, bg: bg };
    setActionsEnabled(true);

    var eccName = ["L", "M", "Q", "H"][qr.errorCorrectionLevel.ordinal];
    var boosted = qr.errorCorrectionLevel !== ECC[el.ecc.value];
    el.info.textContent =
      "الإصدار " + qr.version + " · " + qr.size + "×" + qr.size + " وحدة" +
      " · تصحيح " + eccName + (boosted ? " (رُفع تلقائيًا)" : "") +
      " · قناع " + qr.mask +
      " · الصورة " + (total * scale) + "×" + (total * scale) + " بكسل";
  }

  function download(blob, name) {
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  }

  function pngBlob(callback) {
    var c = document.createElement("canvas");
    drawToCanvas(c, current.qr, current.scale, current.border, current.fg, current.bg);
    c.toBlob(callback, "image/png");
  }

  el.dlPng.addEventListener("click", function () {
    if (!current) return;
    pngBlob(function (blob) {
      if (blob) download(blob, "qrcode.png");
    });
  });

  el.dlSvg.addEventListener("click", function () {
    if (!current) return;
    var svg = toSvg(current.qr, current.scale, current.border, current.fg, current.bg);
    download(new Blob([svg], { type: "image/svg+xml" }), "qrcode.svg");
  });

  el.copy.addEventListener("click", function () {
    if (!current) return;
    if (!navigator.clipboard || typeof ClipboardItem === "undefined") {
      showToast("متصفحك لا يدعم نسخ الصور. استخدم زر التحميل.");
      return;
    }
    var item = new ClipboardItem({
      "image/png": new Promise(function (resolve, reject) {
        pngBlob(function (blob) { blob ? resolve(blob) : reject(new Error("png")); });
      })
    });
    navigator.clipboard.write([item]).then(
      function () { showToast("تم نسخ الصورة."); },
      function () { showToast("تعذّر النسخ. استخدم زر التحميل."); }
    );
  });

  ["input", "change"].forEach(function (evt) {
    [el.text, el.ecc, el.mask, el.boost, el.size, el.margin, el.fg, el.bg]
      .forEach(function (node) { node.addEventListener(evt, render); });
  });

  render();
})();
